-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 16, 2023 at 06:58 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kufa`
--

-- --------------------------------------------------------

--
-- Table structure for table `aboutme`
--

CREATE TABLE `aboutme` (
  `id` int(11) NOT NULL,
  `image` varchar(50) NOT NULL,
  `heading` varchar(100) NOT NULL,
  `description` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `aboutme`
--

INSERT INTO `aboutme` (`id`, `image`, `heading`, `description`) VALUES
(1, 'default.png', 'about me', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rerum, sed repudiandae odit deserunt, quas quibusdam necessitatibus nesciunt eligendi esse sit non reprehenderit quisquam asperiores maxime blanditiis culpa vitae velit. Numquam!');

-- --------------------------------------------------------

--
-- Table structure for table `achievements`
--

CREATE TABLE `achievements` (
  `id` int(11) NOT NULL,
  `icon` varchar(200) NOT NULL,
  `total_number` int(11) NOT NULL,
  `title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `achievements`
--

INSERT INTO `achievements` (`id`, `icon`, `total_number`, `title`) VALUES
(1, 'flaticon-award', 120, 'active product'),
(6, 'flaticon-event', 12054, 'h'),
(7, 'fab fa-free-code-camp', 245, 'f');

-- --------------------------------------------------------

--
-- Table structure for table `contuct_informations`
--

CREATE TABLE `contuct_informations` (
  `id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `heading` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contuct_informations`
--

INSERT INTO `contuct_informations` (`id`, `description`, `heading`, `address`, `phone`, `email`) VALUES
(1, 'Event definition is - somthing that happens occurre How evesnt sentence. Synonym when an unknown printer took a galley.', 'Dhaka Bangladesh', 'Dhanmonddi Dhaka,Bangladesh', '01610126347', 'laraveldevelopr.bd@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `educatioal_qualifications`
--

CREATE TABLE `educatioal_qualifications` (
  `id` int(11) NOT NULL,
  `year` int(4) NOT NULL,
  `title` varchar(200) NOT NULL,
  `progress_with` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `educatioal_qualifications`
--

INSERT INTO `educatioal_qualifications` (`id`, `year`, `title`, `progress_with`) VALUES
(1, 2016, 'Secondary', 80),
(2, 2020, 'Diploma in CMT', 70);

-- --------------------------------------------------------

--
-- Table structure for table `fbanners`
--

CREATE TABLE `fbanners` (
  `id` int(1) NOT NULL,
  `heading` varchar(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` varchar(255) NOT NULL,
  `banner_image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fbanners`
--

INSERT INTO `fbanners` (`id`, `heading`, `name`, `description`, `banner_image`) VALUES
(1, 'Team From Bangladesh', 'I\'am will Smith...A web developer From Bangladesh', 'To Represent my country I will do hardwork for any situation ....', '1.png');

-- --------------------------------------------------------

--
-- Table structure for table `ffooter`
--

CREATE TABLE `ffooter` (
  `id` int(1) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ffooter`
--

INSERT INTO `ffooter` (`id`, `description`) VALUES
(1, 'Copyright description');

-- --------------------------------------------------------

--
-- Table structure for table `flogos`
--

CREATE TABLE `flogos` (
  `id` int(11) NOT NULL,
  `logo_name` varchar(100) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 0,
  `logo_pic` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `flogos`
--

INSERT INTO `flogos` (`id`, `logo_name`, `status`, `logo_pic`) VALUES
(1, 'Upwork', 1, '1.png'),
(3, 'Bkash', 0, '3.png'),
(10, 'kufa', 0, '10.png'),
(12, 'GSDFSD', 0, '12.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `fmenu`
--

CREATE TABLE `fmenu` (
  `id` int(2) NOT NULL,
  `menu` varchar(50) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 0,
  `section_id` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fmenu`
--

INSERT INTO `fmenu` (`id`, `menu`, `status`, `section_id`) VALUES
(1, 'Home', 1, 'home'),
(2, 'about', 1, 'about'),
(3, 'service', 1, 'service'),
(4, 'portfolio', 1, 'portfolio'),
(5, 'contact', 1, 'contact'),
(6, 'brands', 1, 'brands');

-- --------------------------------------------------------

--
-- Table structure for table `fportfolios`
--

CREATE TABLE `fportfolios` (
  `id` int(11) NOT NULL,
  `author` int(11) NOT NULL,
  `portfolio_title` varchar(100) NOT NULL,
  `portfolio_category` varchar(50) NOT NULL,
  `portfolio_image` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fportfolios`
--

INSERT INTO `fportfolios` (`id`, `author`, `portfolio_title`, `portfolio_category`, `portfolio_image`) VALUES
(1, 7, 'Awesome Design', 'Graphics', 'default.png');

-- --------------------------------------------------------

--
-- Table structure for table `fservices`
--

CREATE TABLE `fservices` (
  `id` int(11) NOT NULL,
  `service_icon` varchar(200) NOT NULL,
  `service_title` varchar(200) NOT NULL,
  `service_description` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fservices`
--

INSERT INTO `fservices` (`id`, `service_icon`, `service_title`, `service_description`) VALUES
(1, 'fab fa-react', 'creative design', 'DFSADFASDFA');

-- --------------------------------------------------------

--
-- Table structure for table `our_members`
--

CREATE TABLE `our_members` (
  `id` int(11) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `our_members`
--

INSERT INTO `our_members` (`id`, `image`) VALUES
(1, 'default.png');

-- --------------------------------------------------------

--
-- Table structure for table `social_icons`
--

CREATE TABLE `social_icons` (
  `id` int(2) NOT NULL,
  `url` varchar(100) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `social_icons`
--

INSERT INTO `social_icons` (`id`, `url`, `icon`, `status`) VALUES
(1, 'https://www.facebook.com/', 'fab fa-facebook-f', 1),
(2, 'https://www.youtube.com', 'fab fa-youtube', 0),
(3, 'https://www.youtube.com', 'fab fa-pinterest', 0),
(4, 'https://www.youtube.com', 'fab fa-instagram', 1),
(5, 'https://www.twitter.com', 'fab fa-twitter', 1),
(6, 'https://www.youtube.com', 'fab fa-linkedin-square', 0),
(7, 'https://www.youtube.com', 'fab fa-yahoo', 0);

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(11) NOT NULL,
  `image` varchar(100) NOT NULL DEFAULT 'default.png',
  `description` varchar(255) NOT NULL,
  `name` varchar(50) NOT NULL,
  `designation` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `image`, `description`, `name`, `designation`) VALUES
(1, 'default.png', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum indust.', 'tailor otwell', 'ceo of laravel'),
(3, 'default.png', 'no need', 'but need', 'for me');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `user_role` int(1) NOT NULL,
  `password` varchar(60) NOT NULL,
  `profile_pic` varchar(100) NOT NULL DEFAULT 'default.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `uname`, `email`, `user_role`, `password`, `profile_pic`) VALUES
(7, 'Ali', 'Faysal', 'Faysal', 'laraveldeveloper.bd@gmail.com', 1, '$2y$10$Gc.sc51dnJeqaWZCeHqk.uEIIjsF6QzWvToadi.JnFvWRw03xBFd2', '7.jpg'),
(8, 'Ali', 'Faysal', 'Faysal', 'faysal@live.ocm', 1, '$2y$10$lyW.a6DvzsPT2dRbrBiMMOJEcwfod01x7vHoiOpfj3KLM2tOuqUFy', 'default.png'),
(9, 'Ali', 'Faruk', 'Faysal2', 'faysal2@live.ocm', 2, '$2y$10$osh9c37sVkM/61J4LUO6Je57sa.zdhEqJSFVia9AGPxGPBhuMvBZK', 'default.png'),
(10, 'Md', 'w', 'adminl', 'tahsan.cit.bd@gmail.com', 2, '$2y$10$zFRTn2V9dKdqGsENZ/Yiw.TDiWCxZ46fqZpcVHmeVl5ZFh/N0bXuG', 'default.png'),
(11, 'faruk', 'Hossen', 'Faruk', 'faruk@live.com', 1, '$2y$10$D00VyOmdn6ma65Wnabu7Ru8uj7eYpxwnqnT4dgZyI4vhYvdqV.bgu', '11.jpg'),
(12, 'Baizid', 'Bhi', 'Baizid', 'baizid@gmail.com', 1, '$2y$10$Y88Ng4demcMXfkF21t/hj.j.4Rj.QyA65045FMfNr4kxjG7qaa47G', '12.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `visitor_contucts`
--

CREATE TABLE `visitor_contucts` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 0,
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `visitor_contucts`
--

INSERT INTO `visitor_contucts` (`id`, `name`, `email`, `description`, `status`, `time`) VALUES
(3, 'Yousuf', 'yousug@sup.com', 'How are you Boss', 1, '2022-11-22 00:26:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aboutme`
--
ALTER TABLE `aboutme`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `achievements`
--
ALTER TABLE `achievements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contuct_informations`
--
ALTER TABLE `contuct_informations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `educatioal_qualifications`
--
ALTER TABLE `educatioal_qualifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fbanners`
--
ALTER TABLE `fbanners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ffooter`
--
ALTER TABLE `ffooter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `flogos`
--
ALTER TABLE `flogos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fmenu`
--
ALTER TABLE `fmenu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fportfolios`
--
ALTER TABLE `fportfolios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fservices`
--
ALTER TABLE `fservices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `our_members`
--
ALTER TABLE `our_members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `social_icons`
--
ALTER TABLE `social_icons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `visitor_contucts`
--
ALTER TABLE `visitor_contucts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aboutme`
--
ALTER TABLE `aboutme`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `achievements`
--
ALTER TABLE `achievements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `contuct_informations`
--
ALTER TABLE `contuct_informations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `educatioal_qualifications`
--
ALTER TABLE `educatioal_qualifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fbanners`
--
ALTER TABLE `fbanners`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ffooter`
--
ALTER TABLE `ffooter`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `flogos`
--
ALTER TABLE `flogos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `fmenu`
--
ALTER TABLE `fmenu`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `fportfolios`
--
ALTER TABLE `fportfolios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `fservices`
--
ALTER TABLE `fservices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `our_members`
--
ALTER TABLE `our_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `social_icons`
--
ALTER TABLE `social_icons`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `visitor_contucts`
--
ALTER TABLE `visitor_contucts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
